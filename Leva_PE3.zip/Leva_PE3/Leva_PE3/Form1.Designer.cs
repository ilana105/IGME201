﻿namespace Leva_PE3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.contact = new System.Windows.Forms.Label();
            this.info = new System.Windows.Forms.Label();
            this.location = new System.Windows.Forms.Label();
            this.form = new System.Windows.Forms.Label();
            this.sendMessage = new System.Windows.Forms.Button();
            this.lastName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.firstName = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.country = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.TextBox();
            this.subject = new System.Windows.Forms.TextBox();
            this.question = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // contact
            // 
            this.contact.AutoSize = true;
            this.contact.Dock = System.Windows.Forms.DockStyle.Left;
            this.contact.Font = new System.Drawing.Font("Bahnschrift SemiLight", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contact.ForeColor = System.Drawing.Color.White;
            this.contact.Location = new System.Drawing.Point(0, 0);
            this.contact.Name = "contact";
            this.contact.Size = new System.Drawing.Size(309, 77);
            this.contact.TabIndex = 0;
            this.contact.Text = "CONTACT";
            this.contact.UseWaitCursor = true;
            this.contact.Click += new System.EventHandler(this.label1_Click);
            // 
            // info
            // 
            this.info.AutoSize = true;
            this.info.Font = new System.Drawing.Font("Bahnschrift SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.info.ForeColor = System.Drawing.Color.White;
            this.info.Location = new System.Drawing.Point(12, 121);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(129, 23);
            this.info.TabIndex = 1;
            this.info.Text = "INFORMATION";
            this.info.Click += new System.EventHandler(this.label2_Click);
            // 
            // location
            // 
            this.location.AutoSize = true;
            this.location.Font = new System.Drawing.Font("Bahnschrift SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.location.ForeColor = System.Drawing.Color.White;
            this.location.Location = new System.Drawing.Point(13, 167);
            this.location.Name = "location";
            this.location.Size = new System.Drawing.Size(134, 56);
            this.location.TabIndex = 2;
            this.location.Text = "Rue du Levant 99 CP 159,\r\nCH - 1920 Martigny 1\r\n+41 27 775 69 18\r\n/ info@whitefro" +
    "ntier.ch";
            // 
            // form
            // 
            this.form.AutoSize = true;
            this.form.Font = new System.Drawing.Font("Bahnschrift SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.form.ForeColor = System.Drawing.Color.White;
            this.form.Location = new System.Drawing.Point(12, 279);
            this.form.Name = "form";
            this.form.Size = new System.Drawing.Size(142, 23);
            this.form.TabIndex = 3;
            this.form.Text = "CONTACT FORM";
            // 
            // sendMessage
            // 
            this.sendMessage.BackColor = System.Drawing.Color.LightGray;
            this.sendMessage.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.sendMessage.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendMessage.ForeColor = System.Drawing.Color.White;
            this.sendMessage.Location = new System.Drawing.Point(16, 597);
            this.sendMessage.Name = "sendMessage";
            this.sendMessage.Size = new System.Drawing.Size(243, 42);
            this.sendMessage.TabIndex = 6;
            this.sendMessage.Text = "SEND YOUR MESSAGE";
            this.sendMessage.UseVisualStyleBackColor = false;
            // 
            // lastName
            // 
            this.lastName.BackColor = System.Drawing.SystemColors.GrayText;
            this.lastName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lastName.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastName.ForeColor = System.Drawing.Color.Gray;
            this.lastName.Location = new System.Drawing.Point(6, 14);
            this.lastName.Multiline = true;
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(270, 25);
            this.lastName.TabIndex = 7;
            this.lastName.Text = "LAST NAME *";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.firstName);
            this.groupBox1.ForeColor = System.Drawing.Color.Gainsboro;
            this.groupBox1.Location = new System.Drawing.Point(16, 317);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 46);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // firstName
            // 
            this.firstName.BackColor = System.Drawing.SystemColors.GrayText;
            this.firstName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.firstName.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstName.ForeColor = System.Drawing.Color.Gray;
            this.firstName.Location = new System.Drawing.Point(6, 16);
            this.firstName.Multiline = true;
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(272, 24);
            this.firstName.TabIndex = 4;
            this.firstName.Text = "FIRST NAME *";
            this.firstName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lastName);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.groupBox2.Location = new System.Drawing.Point(341, 318);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(306, 45);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.country);
            this.groupBox3.Location = new System.Drawing.Point(16, 369);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(309, 45);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.email);
            this.groupBox4.Location = new System.Drawing.Point(342, 369);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(304, 44);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.subject);
            this.groupBox5.Location = new System.Drawing.Point(16, 420);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(630, 56);
            this.groupBox5.TabIndex = 12;
            this.groupBox5.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.question);
            this.groupBox6.Location = new System.Drawing.Point(16, 482);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(630, 100);
            this.groupBox6.TabIndex = 13;
            this.groupBox6.TabStop = false;
            // 
            // country
            // 
            this.country.BackColor = System.Drawing.SystemColors.GrayText;
            this.country.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.country.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.country.ForeColor = System.Drawing.Color.Gray;
            this.country.Location = new System.Drawing.Point(6, 15);
            this.country.Multiline = true;
            this.country.Name = "country";
            this.country.Size = new System.Drawing.Size(286, 20);
            this.country.TabIndex = 0;
            this.country.Text = "COUNTRY";
            this.country.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // email
            // 
            this.email.BackColor = System.Drawing.SystemColors.GrayText;
            this.email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.email.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Gray;
            this.email.Location = new System.Drawing.Point(7, 15);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(291, 20);
            this.email.TabIndex = 0;
            this.email.Text = "EMAIL ADDRESS *";
            this.email.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // subject
            // 
            this.subject.BackColor = System.Drawing.SystemColors.GrayText;
            this.subject.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.subject.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subject.ForeColor = System.Drawing.Color.Gray;
            this.subject.Location = new System.Drawing.Point(7, 20);
            this.subject.Name = "subject";
            this.subject.Size = new System.Drawing.Size(617, 20);
            this.subject.TabIndex = 0;
            this.subject.Text = "SUBJECT *";
            // 
            // question
            // 
            this.question.BackColor = System.Drawing.SystemColors.GrayText;
            this.question.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.question.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question.ForeColor = System.Drawing.Color.Gray;
            this.question.Location = new System.Drawing.Point(7, 20);
            this.question.Multiline = true;
            this.question.Name = "question";
            this.question.Size = new System.Drawing.Size(617, 74);
            this.question.TabIndex = 0;
            this.question.Text = "YOUR QUESTION *";
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Bahnschrift SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(334, 118);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(312, 35);
            this.button1.TabIndex = 14;
            this.button1.Text = "BECOME ONE OF OUR AMBASSADORS";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Bahnschrift SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.Window;
            this.button2.Location = new System.Drawing.Point(335, 156);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(312, 35);
            this.button2.TabIndex = 15;
            this.button2.Text = "HOW TO PURCHASE OUR BEERS ONLINE ?";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("Bahnschrift SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.Window;
            this.button3.Location = new System.Drawing.Point(335, 194);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(312, 35);
            this.button3.TabIndex = 16;
            this.button3.Text = "DO YOU WANT TO SELL OUR BEERS ?";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button4_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Gainsboro;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4.Font = new System.Drawing.Font("Bahnschrift SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.Window;
            this.button4.Location = new System.Drawing.Point(335, 232);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(312, 35);
            this.button4.TabIndex = 17;
            this.button4.Text = "A COOL, FRESH BEER AT YOUR EVENT ?";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(678, 686);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.sendMessage);
            this.Controls.Add(this.form);
            this.Controls.Add(this.location);
            this.Controls.Add(this.info);
            this.Controls.Add(this.contact);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.Name = "Form1";
            this.Text = "PE3";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label contact;
        private System.Windows.Forms.Label info;
        private System.Windows.Forms.Label location;
        private System.Windows.Forms.Label form;
        private System.Windows.Forms.Button sendMessage;
        private System.Windows.Forms.TextBox lastName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox firstName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox country;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.TextBox subject;
        private System.Windows.Forms.TextBox question;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}

